#!/bin/sh

set -e

echo "==================================="
echo "Laboratory Forms System Startup"
echo "==================================="

echo "Waiting for PostgreSQL..."

until python - <<EOF
import os
import psycopg2

try:
    psycopg2.connect(
        os.getenv(
            "DATABASE_URL",
            "postgresql://formsuser:formspassword@postgres:5432/formsdb"
        )
    )
    print("Database ready")
except Exception:
    raise SystemExit(1)
EOF
do
    echo "PostgreSQL not ready..."
    sleep 2
done

echo "Running database migrations..."

# flask db upgrade

echo "Creating required directories..."

mkdir -p uploads
mkdir -p uploads/imports

mkdir -p generated
mkdir -p generated/pdfs
mkdir -p generated/csv
mkdir -p generated/barcodes
mkdir -p generated/exports

mkdir -p backups
mkdir -p logs

echo "Starting application..."

exec "$@"