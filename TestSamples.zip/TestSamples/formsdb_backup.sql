--
-- PostgreSQL database dump
--

\restrict SAKuArX8S8utSspqApgvfQLuUkGcSOcLoBZdRWDmqfZ3XEeh0aluQTmyEbpO5Vi

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg13+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: formsuser
--

CREATE TABLE public.audit_logs (
    id integer NOT NULL,
    action character varying(255) NOT NULL,
    user_id integer,
    object_type character varying(100),
    object_id character varying(100),
    details text,
    ip_address character varying(100),
    request_id character varying(255),
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO formsuser;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: formsuser
--

CREATE SEQUENCE public.audit_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_logs_id_seq OWNER TO formsuser;

--
-- Name: audit_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: formsuser
--

ALTER SEQUENCE public.audit_logs_id_seq OWNED BY public.audit_logs.id;


--
-- Name: backup_jobs; Type: TABLE; Schema: public; Owner: formsuser
--

CREATE TABLE public.backup_jobs (
    id integer NOT NULL,
    backup_filename character varying(500),
    status character varying(50) NOT NULL,
    progress_percent integer NOT NULL,
    current_step character varying(255),
    backup_type character varying(50) NOT NULL,
    file_size_bytes bigint,
    checksum character varying(255),
    verified boolean,
    error_message text,
    created_by integer,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.backup_jobs OWNER TO formsuser;

--
-- Name: backup_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: formsuser
--

CREATE SEQUENCE public.backup_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.backup_jobs_id_seq OWNER TO formsuser;

--
-- Name: backup_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: formsuser
--

ALTER SEQUENCE public.backup_jobs_id_seq OWNED BY public.backup_jobs.id;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: formsuser
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    customer_name character varying(255) NOT NULL,
    customer_code character varying(100) NOT NULL,
    contact_number character varying(100),
    active boolean,
    deleted boolean NOT NULL,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone,
    updated_at timestamp without time zone
);


ALTER TABLE public.customers OWNER TO formsuser;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: formsuser
--

CREATE SEQUENCE public.customers_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_id_seq OWNER TO formsuser;

--
-- Name: customers_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: formsuser
--

ALTER SEQUENCE public.customers_id_seq OWNED BY public.customers.id;


--
-- Name: email_queue; Type: TABLE; Schema: public; Owner: formsuser
--

CREATE TABLE public.email_queue (
    id integer NOT NULL,
    submission_id integer,
    recipients json NOT NULL,
    subject character varying(500) NOT NULL,
    body text NOT NULL,
    attachments json,
    email_type character varying(50),
    status character varying(50),
    retry_count integer,
    recipient_count integer,
    attachment_count integer,
    smtp_response text,
    failure_reason text,
    processing_started_at timestamp without time zone,
    processing_finished_at timestamp without time zone,
    sent_at timestamp without time zone,
    last_retry_at timestamp without time zone,
    delivery_duration_ms integer,
    deleted boolean NOT NULL,
    deleted_at timestamp without time zone,
    created_at timestamp without time zone
);


ALTER TABLE public.email_queue OWNER TO formsuser;

--
-- Name: email_queue_id_seq; Type: SEQUENCE; Schema: public; Owner: formsuser
--

CREATE SEQUENCE public.email_queue_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.email_queue_id_seq OWNER TO formsuser;

--
-- Name: email_queue_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: formsuser
--

ALTER SEQUENCE public.email_queue_id_seq OWNED BY public.email_queue.id;


--
-- Name: failure_logs; Type: TABLE; Schema: public; Owner: formsuser
--

CREATE TABLE public.failure_logs (
    id integer NOT NULL,
    source character varying(255) NOT NULL,
    severity character varying(50) NOT NULL,
    error_message text NOT NULL,
    stack_trace text,
    object_type character varying(100),
    object_id character varying(100),
    user_id integer,
    request_id character varying(255),
    resolved boolean NOT NULL,
    resolution_notes text,
    resolved_by integer,
    resolved_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.failure_logs OWNER TO formsuser;

--
-- Name: failure_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: formsuser
--

CREATE SEQUENCE public.failure_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.failure_logs_id_seq OWNER TO formsuser;

--
-- Name: failure_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: formsuser
--

ALTER SEQUENCE public.failure_logs_id_seq OWNED BY public.failure_logs.id;


--
-- Name: request_metrics; Type: TABLE; Schema: public; Owner: formsuser
--

CREATE TABLE public.request_metrics (
    id integer NOT NULL,
    endpoint character varying(500) NOT NULL,
    method character varying(20) NOT NULL,
    status_code integer NOT NULL,
    response_time_ms double precision,
    ip_address character varying(100),
    user_id integer,
    request_id character varying(255),
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.request_metrics OWNER TO formsuser;

--
-- Name: request_metrics_id_seq; Type: SEQUENCE; Schema: public; Owner: formsuser
--

CREATE SEQUENCE public.request_metrics_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.request_metrics_id_seq OWNER TO formsuser;

--
-- Name: request_metrics_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: formsuser
--

ALTER SEQUENCE public.request_metrics_id_seq OWNED BY public.request_metrics.id;


--
-- Name: restore_jobs; Type: TABLE; Schema: public; Owner: formsuser
--

CREATE TABLE public.restore_jobs (
    id integer NOT NULL,
    backup_filename character varying(500) NOT NULL,
    safety_backup_file character varying(500),
    status character varying(50) NOT NULL,
    progress_percent integer NOT NULL,
    current_step character varying(255),
    error_message text,
    started_by integer,
    started_at timestamp without time zone,
    completed_at timestamp without time zone,
    rollback_attempted boolean NOT NULL,
    rollback_successful boolean,
    rollback_error text,
    rollback_completed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.restore_jobs OWNER TO formsuser;

--
-- Name: restore_jobs_id_seq; Type: SEQUENCE; Schema: public; Owner: formsuser
--

CREATE SEQUENCE public.restore_jobs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.restore_jobs_id_seq OWNER TO formsuser;

--
-- Name: restore_jobs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: formsuser
--

ALTER SEQUENCE public.restore_jobs_id_seq OWNED BY public.restore_jobs.id;


--
-- Name: service_uptime; Type: TABLE; Schema: public; Owner: formsuser
--

CREATE TABLE public.service_uptime (
    id integer NOT NULL,
    service_name character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    uptime_seconds bigint NOT NULL,
    started_at timestamp without time zone,
    last_seen timestamp without time zone NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.service_uptime OWNER TO formsuser;

--
-- Name: service_uptime_id_seq; Type: SEQUENCE; Schema: public; Owner: formsuser
--

CREATE SEQUENCE public.service_uptime_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.service_uptime_id_seq OWNER TO formsuser;

--
-- Name: service_uptime_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: formsuser
--

ALTER SEQUENCE public.service_uptime_id_seq OWNED BY public.service_uptime.id;


--
-- Name: settings; Type: TABLE; Schema: public; Owner: formsuser
--

CREATE TABLE public.settings (
    id integer NOT NULL,
    logo_file character varying(500),
    smtp_server character varying(255),
    smtp_port integer,
    smtp_username character varying(255),
    smtp_password character varying(255)
);


ALTER TABLE public.settings OWNER TO formsuser;

--
-- Name: settings_id_seq; Type: SEQUENCE; Schema: public; Owner: formsuser
--

CREATE SEQUENCE public.settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.settings_id_seq OWNER TO formsuser;

--
-- Name: settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: formsuser
--

ALTER SEQUENCE public.settings_id_seq OWNED BY public.settings.id;


--
-- Name: submissions; Type: TABLE; Schema: public; Owner: formsuser
--

CREATE TABLE public.submissions (
    id integer NOT NULL,
    user_id integer,
    submitted_at timestamp without time zone,
    field_data json,
    comments text,
    pdf_path character varying(500),
    csv_path character varying(500)
);


ALTER TABLE public.submissions OWNER TO formsuser;

--
-- Name: submissions_id_seq; Type: SEQUENCE; Schema: public; Owner: formsuser
--

CREATE SEQUENCE public.submissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.submissions_id_seq OWNER TO formsuser;

--
-- Name: submissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: formsuser
--

ALTER SEQUENCE public.submissions_id_seq OWNED BY public.submissions.id;


--
-- Name: system_health; Type: TABLE; Schema: public; Owner: formsuser
--

CREATE TABLE public.system_health (
    id integer NOT NULL,
    service_name character varying(255) NOT NULL,
    status character varying(50) NOT NULL,
    message text,
    checked_at timestamp without time zone NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.system_health OWNER TO formsuser;

--
-- Name: system_health_id_seq; Type: SEQUENCE; Schema: public; Owner: formsuser
--

CREATE SEQUENCE public.system_health_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_health_id_seq OWNER TO formsuser;

--
-- Name: system_health_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: formsuser
--

ALTER SEQUENCE public.system_health_id_seq OWNED BY public.system_health.id;


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: formsuser
--

CREATE TABLE public.system_settings (
    id integer NOT NULL,
    company_name character varying(255),
    smtp_server character varying(255),
    smtp_port integer,
    smtp_username character varying(255),
    smtp_password text,
    smtp_sender_name character varying(255),
    smtp_sender_address character varying(255),
    smtp_use_tls boolean NOT NULL,
    max_login_attempts integer NOT NULL,
    session_timeout_minutes integer NOT NULL,
    monitoring_enabled boolean NOT NULL,
    prometheus_enabled boolean NOT NULL,
    grafana_enabled boolean NOT NULL,
    auto_print_on_submit boolean NOT NULL,
    enable_browser_printing boolean NOT NULL,
    setup_completed boolean NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    sandbox_enabled boolean DEFAULT true NOT NULL,
    sandbox_pending_disable boolean DEFAULT false NOT NULL,
    sandbox_initialized_at timestamp without time zone
);


ALTER TABLE public.system_settings OWNER TO formsuser;

--
-- Name: system_settings_id_seq; Type: SEQUENCE; Schema: public; Owner: formsuser
--

CREATE SEQUENCE public.system_settings_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.system_settings_id_seq OWNER TO formsuser;

--
-- Name: system_settings_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: formsuser
--

ALTER SEQUENCE public.system_settings_id_seq OWNED BY public.system_settings.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: formsuser
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255) NOT NULL,
    password_hash character varying(255) NOT NULL,
    role character varying(20) NOT NULL,
    active boolean NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO formsuser;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: formsuser
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO formsuser;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: formsuser
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: audit_logs id; Type: DEFAULT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.audit_logs ALTER COLUMN id SET DEFAULT nextval('public.audit_logs_id_seq'::regclass);


--
-- Name: backup_jobs id; Type: DEFAULT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.backup_jobs ALTER COLUMN id SET DEFAULT nextval('public.backup_jobs_id_seq'::regclass);


--
-- Name: customers id; Type: DEFAULT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.customers ALTER COLUMN id SET DEFAULT nextval('public.customers_id_seq'::regclass);


--
-- Name: email_queue id; Type: DEFAULT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.email_queue ALTER COLUMN id SET DEFAULT nextval('public.email_queue_id_seq'::regclass);


--
-- Name: failure_logs id; Type: DEFAULT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.failure_logs ALTER COLUMN id SET DEFAULT nextval('public.failure_logs_id_seq'::regclass);


--
-- Name: request_metrics id; Type: DEFAULT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.request_metrics ALTER COLUMN id SET DEFAULT nextval('public.request_metrics_id_seq'::regclass);


--
-- Name: restore_jobs id; Type: DEFAULT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.restore_jobs ALTER COLUMN id SET DEFAULT nextval('public.restore_jobs_id_seq'::regclass);


--
-- Name: service_uptime id; Type: DEFAULT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.service_uptime ALTER COLUMN id SET DEFAULT nextval('public.service_uptime_id_seq'::regclass);


--
-- Name: settings id; Type: DEFAULT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.settings ALTER COLUMN id SET DEFAULT nextval('public.settings_id_seq'::regclass);


--
-- Name: submissions id; Type: DEFAULT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.submissions ALTER COLUMN id SET DEFAULT nextval('public.submissions_id_seq'::regclass);


--
-- Name: system_health id; Type: DEFAULT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.system_health ALTER COLUMN id SET DEFAULT nextval('public.system_health_id_seq'::regclass);


--
-- Name: system_settings id; Type: DEFAULT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.system_settings ALTER COLUMN id SET DEFAULT nextval('public.system_settings_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: formsuser
--

COPY public.audit_logs (id, action, user_id, object_type, object_id, details, ip_address, request_id, created_at) FROM stdin;
\.


--
-- Data for Name: backup_jobs; Type: TABLE DATA; Schema: public; Owner: formsuser
--

COPY public.backup_jobs (id, backup_filename, status, progress_percent, current_step, backup_type, file_size_bytes, checksum, verified, error_message, created_by, started_at, completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: formsuser
--

COPY public.customers (id, customer_name, customer_code, contact_number, active, deleted, deleted_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_queue; Type: TABLE DATA; Schema: public; Owner: formsuser
--

COPY public.email_queue (id, submission_id, recipients, subject, body, attachments, email_type, status, retry_count, recipient_count, attachment_count, smtp_response, failure_reason, processing_started_at, processing_finished_at, sent_at, last_retry_at, delivery_duration_ms, deleted, deleted_at, created_at) FROM stdin;
\.


--
-- Data for Name: failure_logs; Type: TABLE DATA; Schema: public; Owner: formsuser
--

COPY public.failure_logs (id, source, severity, error_message, stack_trace, object_type, object_id, user_id, request_id, resolved, resolution_notes, resolved_by, resolved_at, created_at) FROM stdin;
\.


--
-- Data for Name: request_metrics; Type: TABLE DATA; Schema: public; Owner: formsuser
--

COPY public.request_metrics (id, endpoint, method, status_code, response_time_ms, ip_address, user_id, request_id, created_at) FROM stdin;
\.


--
-- Data for Name: restore_jobs; Type: TABLE DATA; Schema: public; Owner: formsuser
--

COPY public.restore_jobs (id, backup_filename, safety_backup_file, status, progress_percent, current_step, error_message, started_by, started_at, completed_at, rollback_attempted, rollback_successful, rollback_error, rollback_completed_at, created_at) FROM stdin;
\.


--
-- Data for Name: service_uptime; Type: TABLE DATA; Schema: public; Owner: formsuser
--

COPY public.service_uptime (id, service_name, status, uptime_seconds, started_at, last_seen, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: formsuser
--

COPY public.settings (id, logo_file, smtp_server, smtp_port, smtp_username, smtp_password) FROM stdin;
\.


--
-- Data for Name: submissions; Type: TABLE DATA; Schema: public; Owner: formsuser
--

COPY public.submissions (id, user_id, submitted_at, field_data, comments, pdf_path, csv_path) FROM stdin;
\.


--
-- Data for Name: system_health; Type: TABLE DATA; Schema: public; Owner: formsuser
--

COPY public.system_health (id, service_name, status, message, checked_at, created_at) FROM stdin;
\.


--
-- Data for Name: system_settings; Type: TABLE DATA; Schema: public; Owner: formsuser
--

COPY public.system_settings (id, company_name, smtp_server, smtp_port, smtp_username, smtp_password, smtp_sender_name, smtp_sender_address, smtp_use_tls, max_login_attempts, session_timeout_minutes, monitoring_enabled, prometheus_enabled, grafana_enabled, auto_print_on_submit, enable_browser_printing, setup_completed, created_at, updated_at, sandbox_enabled, sandbox_pending_disable, sandbox_initialized_at) FROM stdin;
1	\N	\N	587	\N	\N	\N	\N	t	5	30	t	f	f	f	t	f	2026-07-13 11:17:22.469016	2026-07-13 11:17:22.469027	t	f	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: formsuser
--

COPY public.users (id, name, email, password_hash, role, active, created_at) FROM stdin;
\.


--
-- Name: audit_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: formsuser
--

SELECT pg_catalog.setval('public.audit_logs_id_seq', 1, false);


--
-- Name: backup_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: formsuser
--

SELECT pg_catalog.setval('public.backup_jobs_id_seq', 1, false);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: formsuser
--

SELECT pg_catalog.setval('public.customers_id_seq', 1, false);


--
-- Name: email_queue_id_seq; Type: SEQUENCE SET; Schema: public; Owner: formsuser
--

SELECT pg_catalog.setval('public.email_queue_id_seq', 1, false);


--
-- Name: failure_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: formsuser
--

SELECT pg_catalog.setval('public.failure_logs_id_seq', 1, false);


--
-- Name: request_metrics_id_seq; Type: SEQUENCE SET; Schema: public; Owner: formsuser
--

SELECT pg_catalog.setval('public.request_metrics_id_seq', 2389, true);


--
-- Name: restore_jobs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: formsuser
--

SELECT pg_catalog.setval('public.restore_jobs_id_seq', 1, false);


--
-- Name: service_uptime_id_seq; Type: SEQUENCE SET; Schema: public; Owner: formsuser
--

SELECT pg_catalog.setval('public.service_uptime_id_seq', 1, false);


--
-- Name: settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: formsuser
--

SELECT pg_catalog.setval('public.settings_id_seq', 1, false);


--
-- Name: submissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: formsuser
--

SELECT pg_catalog.setval('public.submissions_id_seq', 1, false);


--
-- Name: system_health_id_seq; Type: SEQUENCE SET; Schema: public; Owner: formsuser
--

SELECT pg_catalog.setval('public.system_health_id_seq', 1, false);


--
-- Name: system_settings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: formsuser
--

SELECT pg_catalog.setval('public.system_settings_id_seq', 1, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: formsuser
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: backup_jobs backup_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.backup_jobs
    ADD CONSTRAINT backup_jobs_pkey PRIMARY KEY (id);


--
-- Name: customers customers_customer_code_key; Type: CONSTRAINT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_customer_code_key UNIQUE (customer_code);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: email_queue email_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.email_queue
    ADD CONSTRAINT email_queue_pkey PRIMARY KEY (id);


--
-- Name: failure_logs failure_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.failure_logs
    ADD CONSTRAINT failure_logs_pkey PRIMARY KEY (id);


--
-- Name: request_metrics request_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.request_metrics
    ADD CONSTRAINT request_metrics_pkey PRIMARY KEY (id);


--
-- Name: restore_jobs restore_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.restore_jobs
    ADD CONSTRAINT restore_jobs_pkey PRIMARY KEY (id);


--
-- Name: service_uptime service_uptime_pkey; Type: CONSTRAINT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.service_uptime
    ADD CONSTRAINT service_uptime_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: submissions submissions_pkey; Type: CONSTRAINT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_pkey PRIMARY KEY (id);


--
-- Name: system_health system_health_pkey; Type: CONSTRAINT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.system_health
    ADD CONSTRAINT system_health_pkey PRIMARY KEY (id);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_audit_logs_action; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: ix_audit_logs_created_at; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_audit_logs_created_at ON public.audit_logs USING btree (created_at);


--
-- Name: ix_audit_logs_object_id; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_audit_logs_object_id ON public.audit_logs USING btree (object_id);


--
-- Name: ix_audit_logs_object_type; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_audit_logs_object_type ON public.audit_logs USING btree (object_type);


--
-- Name: ix_audit_logs_user_id; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: ix_backup_jobs_created_at; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_backup_jobs_created_at ON public.backup_jobs USING btree (created_at);


--
-- Name: ix_backup_jobs_status; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_backup_jobs_status ON public.backup_jobs USING btree (status);


--
-- Name: ix_failure_logs_created_at; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_failure_logs_created_at ON public.failure_logs USING btree (created_at);


--
-- Name: ix_failure_logs_object_id; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_failure_logs_object_id ON public.failure_logs USING btree (object_id);


--
-- Name: ix_failure_logs_object_type; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_failure_logs_object_type ON public.failure_logs USING btree (object_type);


--
-- Name: ix_failure_logs_resolved; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_failure_logs_resolved ON public.failure_logs USING btree (resolved);


--
-- Name: ix_failure_logs_severity; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_failure_logs_severity ON public.failure_logs USING btree (severity);


--
-- Name: ix_failure_logs_source; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_failure_logs_source ON public.failure_logs USING btree (source);


--
-- Name: ix_failure_logs_user_id; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_failure_logs_user_id ON public.failure_logs USING btree (user_id);


--
-- Name: ix_request_metrics_created_at; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_request_metrics_created_at ON public.request_metrics USING btree (created_at);


--
-- Name: ix_request_metrics_endpoint; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_request_metrics_endpoint ON public.request_metrics USING btree (endpoint);


--
-- Name: ix_request_metrics_user_id; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_request_metrics_user_id ON public.request_metrics USING btree (user_id);


--
-- Name: ix_restore_jobs_created_at; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_restore_jobs_created_at ON public.restore_jobs USING btree (created_at);


--
-- Name: ix_restore_jobs_status; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_restore_jobs_status ON public.restore_jobs USING btree (status);


--
-- Name: ix_service_uptime_service_name; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_service_uptime_service_name ON public.service_uptime USING btree (service_name);


--
-- Name: ix_system_health_service_name; Type: INDEX; Schema: public; Owner: formsuser
--

CREATE INDEX ix_system_health_service_name ON public.system_health USING btree (service_name);


--
-- Name: submissions submissions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: formsuser
--

ALTER TABLE ONLY public.submissions
    ADD CONSTRAINT submissions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict SAKuArX8S8utSspqApgvfQLuUkGcSOcLoBZdRWDmqfZ3XEeh0aluQTmyEbpO5Vi

