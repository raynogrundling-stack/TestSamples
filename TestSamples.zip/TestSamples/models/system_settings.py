from datetime import datetime
from extensions import db
class SystemSettings(db.Model):
    __tablename__ = "system_settings"
    id = db.Column(
        db.Integer,
        primary_key=True
    )
    sandbox_enabled = db.Column(
        db.Boolean,
        nullable=False,
        default=True
    )
    sandbox_pending_disable = db.Column(
        db.Boolean,
        nullable=False,
        default=False
    )
    sandbox_initialized_at = db.Column(
        db.DateTime,
        nullable=True
    )
    company_name = db.Column(
        db.String(255),
        nullable=True
    )
    company_logo = db.Column(
        db.String(500),
        nullable=True
    )
    smtp_server = db.Column(
        db.String(255),
        nullable=True
    )
    smtp_port = db.Column(
        db.Integer,
        nullable=True,
        default=587
    )
    smtp_username = db.Column(
        db.String(255),
        nullable=True
    )
    smtp_password = db.Column(
        db.Text,
        nullable=True
    )
    smtp_sender_name = db.Column(
        db.String(255),
        nullable=True
    )
    smtp_sender_address = db.Column(
        db.String(255),
        nullable=True
    )
    smtp_use_tls = db.Column(
        db.Boolean,
        nullable=False,
        default=True
    )
    max_login_attempts = db.Column(
        db.Integer,
        nullable=False,
        default=5
    )
    session_timeout_minutes = db.Column(
        db.Integer,
        nullable=False,
        default=30
    )
    monitoring_enabled = db.Column(
        db.Boolean,
        nullable=False,
        default=True
    )
    prometheus_enabled = db.Column(
        db.Boolean,
        nullable=False,
        default=False
    )
    grafana_enabled = db.Column(
        db.Boolean,
        nullable=False,
        default=False
    )
    auto_print_on_submit = db.Column(
        db.Boolean,
        nullable=False,
        default=False
    )
    enable_browser_printing = db.Column(
        db.Boolean,
        nullable=False,
        default=True
    )
    setup_completed = db.Column(
        db.Boolean,
        nullable=False,
        default=False
    )
    created_at = db.Column(
        db.DateTime,
        default=datetime.utcnow
    )
    updated_at = db.Column(
        db.DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )
    def __repr__(self):
        return (
            f"<SystemSettings "
            f"{self.company_name}>"
        )